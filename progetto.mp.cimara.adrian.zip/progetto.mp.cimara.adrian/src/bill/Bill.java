package bill;

public interface Bill {
	
	String getDescription();
	
}
