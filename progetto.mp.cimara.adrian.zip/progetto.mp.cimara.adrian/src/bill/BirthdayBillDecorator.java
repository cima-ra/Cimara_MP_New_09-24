package bill;

public class BirthdayBillDecorator extends BillDecorator {

	public BirthdayBillDecorator(Bill billDecorated) {
		super(billDecorated);
	}
	
	@Override
	public String getDescription() {
		return super.getDescription() + " Scontrino di cortesia. Tanti auguri e buon compleanno!!";
	}

}
